(function () {
  'use strict';

  var GAME_META = [
    { id: 'genshin', name: '原神', short: '原神', color: '#f2c14e', source: 'https://www.miyoushe.com/ys/' },
    { id: 'hsr', name: '崩坏：星穹铁道', short: '星铁', color: '#8ba4ff', source: 'https://www.miyoushe.com/sr/' },
    { id: 'zzz', name: '绝区零', short: '绝区零', color: '#ffd166', source: 'https://www.miyoushe.com/zzz/' },
    { id: 'arknights', name: '明日方舟', short: '明日方舟', color: '#8b8b8b', source: 'https://prts.wiki/' },
    { id: 'wuwa', name: '鸣潮', short: '鸣潮', color: '#9fb4c9', source: 'https://www.kurobbs.com/mc/home/9' },
    { id: 'endfield', name: '明日方舟：终末地', short: '终末地', color: '#7fd6c2', source: 'https://www.skland.com/game/endfield' }
  ];
  var GAME_MAP = {};
  GAME_META.forEach(function (g) { GAME_MAP[g.id] = g; });

  var NOTICES = {
    genshin: {
      title: '原神：角色列表能拿到，材料详情没能匿名读取',
      reason: '已确认米游社观测枢能返回 138 个角色条目，但角色详情 / 材料接口未返回可匿名读取的数据，无法可靠生成全角色材料表。',
      checked: ['米游社原神社区', '米游社观测枢角色频道']
    },
    hsr: {
      title: '星铁：没找到可用的角色材料频道',
      reason: '米游社星铁 wiki 接口可访问，但未定位到能返回全角色培养材料的频道，因此没有生成数据。',
      checked: ['米游社星铁社区', '米游社星铁 wiki']
    },
    zzz: {
      title: '绝区零：官方 wiki 未返回角色材料',
      reason: '米游社绝区零 wiki 接口未返回角色材料数据，无法确认全角色材料来源。',
      checked: ['米游社绝区零社区', '米游社绝区零 wiki']
    },
    wuwa: {
      title: '鸣潮：库街区需要登录令牌',
      reason: '库街区官方接口需要登录 token / uid，未配置时无法批量读取全角色材料；没有用社区数据补猜。',
      checked: ['库街区鸣潮官方社区']
    },
    endfield: {
      title: '终末地：没有公开的全角色材料接口',
      reason: '森空岛页面未提供可匿名批量读取的角色材料接口，无法可靠生成全角色材料表。',
      checked: ['森空岛终末地页面']
    }
  };

  var RARITY_COLOR = {
    6: '#ffb54d', 5: '#ffd76a', 4: '#c89bff', 3: '#6fb4ff', 2: '#8ee08a', 1: '#aab3c7'
  };
  var CLASS_ORDER = ['先锋', '近卫', '重装', '狙击', '术师', '医疗', '辅助', '特种'];

  var state = { game: 'arknights', q: '', rarity: 'all', cls: 'all', selected: '', sort: 'release-desc' };
  var ARK = null;

  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (m) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[m];
    });
  }
  function rarityColor(r) { return RARITY_COLOR[r] || '#aab3c7'; }
  function stars(r) { return r ? '★'.repeat(Math.max(0, Math.min(6, r))) : ''; }
  function isMobile() {
    return window.GROWTH_MODE === 'h5' || window.matchMedia('(max-width: 900px)').matches;
  }

  function avatarHTML(o, cls) {
    var rc = rarityColor(o.rarity);
    return '<span class="' + cls + '" style="--rc:' + rc + '">' +
      '<span class="g-avatar-fallback">' + esc(o.name.slice(0, 1)) + '</span>' +
      (o.avatar
        ? '<img src="' + esc(o.avatar) + '" alt="' + esc(o.name) + '" loading="lazy" onerror="this.remove()">'
        : '') +
      '</span>';
  }

  function renderTabs() {
    document.getElementById('gTabs').innerHTML = GAME_META.map(function (g) {
      var count = g.id === 'arknights' && ARK ? ARK.count : 0;
      return '<button class="g-tab' + (state.game === g.id ? ' on' : '') + (count ? '' : ' off') +
        '" style="--c:' + g.color + '" data-game="' + g.id + '"><i></i>' + esc(g.short) +
        '<span class="cnt">' + (count ? count + ' 名' : '未收录') + '</span></button>';
    }).join('');
  }

  function renderNotice(gameId) {
    var g = GAME_MAP[gameId];
    var n = NOTICES[gameId];
    return '<article class="g-notice">' +
      '<div class="eyebrow">未找到可靠数据 · 未生成材料表</div>' +
      '<h2>' + esc(n.title) + '</h2>' +
      '<p>' + esc(n.reason) + '</p>' +
      '<ul><li>已检查：' + n.checked.map(esc).join('、') + '</li>' +
      '<li>没有使用猜测数据；不完整的表比错表更危险。</li></ul>' +
      '<div class="actions"><a href="' + g.source + '" target="_blank" rel="noopener">打开' + esc(g.name) + '官方站点 ↗</a>' +
      '<a href="https://prts.wiki/" target="_blank" rel="noopener">查看已收录的明日方舟全量材料 ↗</a></div>' +
      '<div class="hint">如果你有该游戏可访问的角色 wiki 页面或材料接口，把链接发我，可以按明日方舟同样的方式补全。</div>' +
      '</article>';
  }

  function classes() {
    var set = {};
    ARK.operators.forEach(function (o) { if (o.class) set[o.class] = 1; });
    return Object.keys(set).sort(function (a, b) {
      var ia = CLASS_ORDER.indexOf(a), ib = CLASS_ORDER.indexOf(b);
      if (ia < 0) ia = 99;
      if (ib < 0) ib = 99;
      return ia - ib || a.localeCompare(b, 'zh-Hans-CN');
    });
  }

  function renderArknights() {
    var main = document.getElementById('gMain');
    var cls = classes();
    main.innerHTML = '<div class="g-layout">' +
      '<aside class="g-side"><div class="g-tools">' +
      '<input class="g-search" id="gSearch" placeholder="搜索干员名…" autocomplete="off">' +
      '<div class="g-sort-row"><button class="g-sort" id="gSort">上线时间 ↓ 新→旧</button><span class="g-count" id="gCount"></span></div>' +
      '<div class="g-filters" id="gRarity"></div>' +
      '<div class="g-filters" id="gClass"></div>' +
      '</div><div class="g-list" id="gList"></div></aside>' +
      '<section class="g-detail" id="gDetail"></section>' +
      '</div><div class="g-backdrop" id="gBackdrop2"></div>';

    document.getElementById('gSearch').addEventListener('input', function (ev) {
      state.q = ev.target.value.trim();
      renderList();
    });
    document.getElementById('gSort').addEventListener('click', function () {
      state.sort = state.sort === 'release-desc' ? 'release-asc' : 'release-desc';
      renderSort();
      renderList();
    });
    document.getElementById('gRarity').addEventListener('click', function (ev) {
      var b = ev.target.closest('[data-rarity]');
      if (!b) return;
      state.rarity = b.getAttribute('data-rarity');
      renderFilters();
      renderList();
    });
    document.getElementById('gClass').addEventListener('click', function (ev) {
      var b = ev.target.closest('[data-cls]');
      if (!b) return;
      state.cls = b.getAttribute('data-cls');
      renderFilters();
      renderList();
    });
    document.getElementById('gList').addEventListener('click', function (ev) {
      var b = ev.target.closest('[data-op]');
      if (!b) return;
      state.selected = b.getAttribute('data-op');
      markSelected();
      renderDetail();
      if (isMobile()) openDetail();
    });
    document.getElementById('gDetail').addEventListener('click', function (ev) {
      if (ev.target.closest('[data-close-detail]')) closeDetail();
    });
    var bd = document.getElementById('gBackdrop2');
    if (bd) bd.addEventListener('click', closeDetail);

    renderFilters();
    renderSort();
    renderList();
  }

  function renderSort() {
    var b = document.getElementById('gSort');
    if (b) b.textContent = state.sort === 'release-desc' ? '上线时间 ↓ 新→旧' : '上线时间 ↑ 旧→新';
  }

  function renderFilters() {
    var rarities = [6, 5, 4, 3, 2, 1].filter(function (r) {
      return ARK.operators.some(function (o) { return o.rarity === r; });
    });
    var rh = '<button class="g-chip' + (state.rarity === 'all' ? ' on' : '') + '" data-rarity="all">全部星级</button>' +
      rarities.map(function (r) {
        return '<button class="g-chip' + (state.rarity === String(r) ? ' on' : '') + '" data-rarity="' + r + '">' + r + '★</button>';
      }).join('');
    var rEl = document.getElementById('gRarity');
    if (rEl) rEl.innerHTML = rh;

    var ch = '<button class="g-chip' + (state.cls === 'all' ? ' on' : '') + '" data-cls="all">全部职业</button>' +
      classes().map(function (c) {
        return '<button class="g-chip' + (state.cls === c ? ' on' : '') + '" data-cls="' + esc(c) + '">' + esc(c) + '</button>';
      }).join('');
    var cEl = document.getElementById('gClass');
    if (cEl) cEl.innerHTML = ch;
  }

  function releaseTime(o) {
    var m = String(o.release || '').match(/^(\d{4})-(\d{1,2})-(\d{1,2})(?:[ T](\d{1,2}):(\d{2}))?/);
    if (!m) return 0;
    return new Date(+m[1], +m[2] - 1, +m[3], +(m[4] || 0), +(m[5] || 0)).getTime();
  }

  function filtered() {
    var q = state.q.toLowerCase();
    return ARK.operators.filter(function (o) {
      if (state.rarity !== 'all' && o.rarity !== Number(state.rarity)) return false;
      if (state.cls !== 'all' && o.class !== state.cls) return false;
      if (q && o.name.toLowerCase().indexOf(q) < 0 && (o.branch || '').toLowerCase().indexOf(q) < 0) return false;
      return true;
    }).sort(function (a, b) {
      var ta = releaseTime(a);
      var tb = releaseTime(b);
      if (!ta && !tb) return (b.rarity || 0) - (a.rarity || 0) || a.name.localeCompare(b.name, 'zh-Hans-CN');
      if (!ta) return 1;
      if (!tb) return -1;
      if (ta !== tb) return state.sort === 'release-asc' ? ta - tb : tb - ta;
      return (b.rarity || 0) - (a.rarity || 0) || a.name.localeCompare(b.name, 'zh-Hans-CN');
    });
  }

  function renderList() {
    var list = filtered();
    var countEl = document.getElementById('gCount');
    if (countEl) countEl.textContent = list.length + ' 名';
    if (!list.some(function (o) { return o.name === state.selected; })) {
      state.selected = list.length ? list[0].name : '';
    }
    var el = document.getElementById('gList');
    if (!el) return;
    el.innerHTML = list.length ? list.map(function (o) {
      var rc = rarityColor(o.rarity);
      return '<button class="g-item' + (o.name === state.selected ? ' on' : '') + '" data-op="' + esc(o.name) + '">' +
        avatarHTML(o, 'g-avatar') +
        '<span class="g-item-main"><b>' + esc(o.name) + '</b><small>' + esc(o.class || '未知') + (o.branch ? ' · ' + esc(o.branch) : '') + '</small></span>' +
        '<span class="g-stars" style="--rc:' + rc + '">' + stars(o.rarity) + '</span>' +
        '</button>';
    }).join('') : '<div class="g-empty-list">没有匹配的干员<br>试试清空搜索或切换筛选</div>';
    renderDetail();
  }

  function markSelected() {
    document.querySelectorAll('#gList .g-item').forEach(function (b) {
      b.classList.toggle('on', b.getAttribute('data-op') === state.selected);
    });
  }

  function matChips(mats) {
    if (!mats || !mats.length) return '<span class="g-none">—</span>';
    return '<div class="g-mats">' + mats.map(function (m) {
      var num = m.qty && m.qty.num != null ? ' title="' + m.qty.num + '"' : '';
      var icon = m.icon
        ? '<img class="g-mat-icon" src="' + esc(m.icon) + '" alt="' + esc(m.name) + '" loading="lazy" onerror="this.remove()">'
        : '<i class="g-mat-dot"></i>';
      return '<span class="g-mat"' + num + '>' + icon +
        '<span>' + esc(m.name) + '</span><b>×' + esc(m.qty ? m.qty.text : '') + '</b></span>';
    }).join('') + '</div>';
  }

  function skillOrder(key) {
    if (/^\d+$/.test(key)) return Number(key);
    var m = key.match(/^([一二三])(\d+)$/);
    if (m) {
      var g = { '一': 0, '二': 1, '三': 2 }[m[1]];
      return 100 + g * 10 + Number(m[2]);
    }
    return 999;
  }
  function skillLabel(key) {
    var m = key.match(/^([一二三])(\d+)$/);
    if (m) return '专精' + m[1] + ' Lv' + m[2];
    return '技能 ' + key;
  }

  function renderDetail() {
    var el = document.getElementById('gDetail');
    if (!el) return;
    var o = ARK.operators.find(function (x) { return x.name === state.selected; });
    if (!o) {
      el.innerHTML = '<div class="g-detail-empty">选择左侧干员查看材料</div>';
      return;
    }
    var rc = rarityColor(o.rarity);
    var elite = o.elite || {};
    var keys = Object.keys(o.skills || {}).sort(function (a, b) { return skillOrder(a) - skillOrder(b); });
    var html = '<div class="g-dhead"><div class="g-dhead-main">' +
      avatarHTML(o, 'g-davatar') +
      '<div>' +
      '<h2><span class="g-rarity" style="--rc:' + rc + '">' + stars(o.rarity) + '</span>' + esc(o.name) +
      '<span class="g-class">' + esc(o.class || '未知') + (o.branch ? ' · ' + esc(o.branch) : '') + '</span></h2>' +
      '<div class="sub">' + (o.tags ? esc(o.tags) : '无标签') + (o.obtain ? ' · 获取：' + esc(o.obtain) : '') + '</div>' +
      '</div></div><div style="display:flex;gap:7px;align-items:center">' +
      '<a class="g-source" href="' + esc(o.url) + '" target="_blank" rel="noopener">PRTS 页面 ↗</a>' +
      '<button class="g-close" data-close-detail aria-label="关闭">×</button></div></div>' +
      '<div class="g-meta"><span>精英化材料</span><span>技能升级材料</span>' +
      (o.release ? '<span>上线 ' + esc(o.release) + '</span>' : '') +
      '<span>数据源：PRTS</span></div>' +
      '<div class="g-sec">精英化材料</div>' +
      '<div class="g-mat-group"><div class="g-mat-label">精英 1</div>' + matChips(elite['精1']) + '</div>' +
      '<div class="g-mat-group"><div class="g-mat-label">精英 2</div>' + matChips(elite['精2']) + '</div>' +
      '<div class="g-sec">技能升级材料</div>';

    if (keys.length) {
      var levelRows = keys.filter(function (k) { return /^\d+$/.test(k); });
      var masterRows = keys.filter(function (k) { return /^[一二三]\d+$/.test(k); });
      if (levelRows.length) {
        html += '<div class="g-mat-label" style="margin:2px 0 4px">技能等级 2 – 7</div>';
        levelRows.forEach(function (k) {
          html += '<div class="g-skill-row"><div class="lbl">' + skillLabel(k) + '</div>' + matChips(o.skills[k]) + '</div>';
        });
      }
      if (masterRows.length) {
        html += '<div class="g-mat-label" style="margin:12px 0 4px">专精一 / 二 / 三</div>';
        masterRows.forEach(function (k) {
          html += '<div class="g-skill-row"><div class="lbl">' + skillLabel(k) + '</div>' + matChips(o.skills[k]) + '</div>';
        });
      }
    } else {
      html += '<div class="g-warn">PRTS 未收录该干员的技能升级材料，可能是特殊/剧情/联动干员，或页面未使用标准材料模板。这里不做补猜。</div>';
    }
    html += '<div class="g-warn" style="margin-top:16px">本页只收录精英化与技能升级材料，未包含模组材料与专精三之后的其他消耗；数量保留 PRTS 原始写法（w = 万）。</div>';
    el.innerHTML = html;
  }

  function openDetail() {
    var d = document.getElementById('gDetail');
    var b = document.getElementById('gBackdrop2');
    if (d) d.classList.add('open');
    if (b) b.classList.add('open');
    document.body.style.overflow = 'hidden';
  }
  function closeDetail() {
    var d = document.getElementById('gDetail');
    var b = document.getElementById('gBackdrop2');
    if (d) d.classList.remove('open');
    if (b) b.classList.remove('open');
    document.body.style.overflow = '';
  }

  function renderMain() {
    renderTabs();
    if (state.game === 'arknights') {
      if (ARK) renderArknights();
      else document.getElementById('gMain').innerHTML = '<div class="g-loading">正在读取 PRTS 材料数据…</div>';
    } else {
      document.getElementById('gMain').innerHTML = renderNotice(state.game);
    }
  }

  document.getElementById('gTabs').addEventListener('click', function (ev) {
    var b = ev.target.closest('[data-game]');
    if (!b) return;
    state.game = b.getAttribute('data-game');
    state.selected = '';
    closeDetail();
    renderMain();
  });

  document.addEventListener('keydown', function (ev) {
    if (ev.key === 'Escape') closeDetail();
  });

  fetch('data/growth/arknights.json')
    .then(function (r) {
      if (!r.ok) throw new Error('HTTP ' + r.status);
      return r.json();
    })
    .then(function (data) {
      ARK = data;
      var c = document.getElementById('gOpCount');
      var u = document.getElementById('gUpdated');
      if (c) c.textContent = data.count;
      if (u) u.textContent = data.updated;
      renderMain();
    })
    .catch(function (err) {
      document.getElementById('gMain').innerHTML =
        '<div class="g-notice"><div class="eyebrow">数据加载失败</div><h2>读取不到 arknights.json</h2>' +
        '<p>' + esc(err.message) + '</p><p>请通过 node server.mjs 的 8001 / 8002 端口打开本页，不要直接双击 HTML。</p></div>';
    });
})();
